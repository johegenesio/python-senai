tempo=str(input('Está frio? Escolha S/N: '))
if(tempo=='S' or tempo=='s'):
    print('Coloque uma blusa de frio')
else:
    print('Não precisa de blusa')