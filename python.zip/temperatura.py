temp=float(input('Qual a temperaura?: '))
if (temp >= 30):
    print('Leve água gelada')
elif (temp >= 20):
    print('O clima está ameno')
else:
    print('Leve blusa')
